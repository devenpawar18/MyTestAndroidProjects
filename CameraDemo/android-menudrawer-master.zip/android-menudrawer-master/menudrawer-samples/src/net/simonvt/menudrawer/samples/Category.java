package net.simonvt.menudrawer.samples;

public class Category {

    String mTitle;

    Category(String title) {
        mTitle = title;
    }
}
